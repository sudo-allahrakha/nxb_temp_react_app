import React from "react";

export default function CategoriesPlaceholder() {
  return (
    <>
      <button
        type="button"
        className="  disabled placeholder col-2  mx-1 my-1 btn btn-danger"
      />
      <button
        type="button"
        className=" disabled placeholder col-2  mx-1 my-1 btn btn-danger"
      />

      <button
        type="button"
        className="  disabled placeholder col-2  mx-1 my-1 btn btn-danger"
      />
      <button
        type="button"
        className="  disabled placeholder col-2  mx-1 my-1 btn btn-danger"
      />
    </>
  );
}
